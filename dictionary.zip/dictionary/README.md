# English to Farsi Dictionary with Audio

Run the project

```
npm install
npm start
```
