interface ICategory {
  English: string;
  Farsi: string;
  Transliteration: string;
  Farsi_Audio: string;
}

export type { ICategory };
