interface ICategory {
  card_name: string;
  words: string[];
  image: string;
  color: string;
}

export type { ICategory };
