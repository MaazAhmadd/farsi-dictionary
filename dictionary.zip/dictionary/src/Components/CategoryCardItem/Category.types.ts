interface ICategory {
  card_name: string;
  words: string[];
}

export type { ICategory };
